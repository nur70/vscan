
known_weak = ['root', 'guest', 'test@123', 'test', 'test123456', '123456', 'password', 'admin', 'administrator']